"use strict";
var url = "http://localhost:5000/hubs/chat";

var connection = new signalR.HubConnectionBuilder().withUrl(url).build();

connection.on("ReciveMessage",function(clientName,message){
    var fullmessage = clientName + " : " + message;
    var li = document.createElement("li");
    li.textContent = fullmessage;
    document.getElementById("list").appendChild(li);
});

connection.start().then(function(){

}).catch(function(err){
    return console.error(err.toString());
});

document.getElementById("send").addEventListener("click",function(event){
    var userName = document.getElementById("username").value;
    var message = document.getElementById("message").value;
    connection.invoke("Send",userName,message).then((val)=>{
        console.log("Send Success");
    }).catch(function(err){
        return console.error(err.toString());
    });
    event.preventDefault();
});