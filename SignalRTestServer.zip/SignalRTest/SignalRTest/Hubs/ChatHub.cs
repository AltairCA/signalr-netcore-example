﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.SignalR;

namespace SignalRTest.Hubs
{
    public class ChatHub:Hub
    {
        public async Task Send(string clientName, string message)
        {
            await Clients.All.SendAsync("ReciveMessage", clientName, message);
        }
    }
}